For Linux OS:
Compile format:
>>gcc main.c -o main -std=c99

Run format:
>>./main <input file> <protocol (MI, MSI, or MESI)>

Example run:
>>./main input4.txt MI
